package Ejercicio1;

public class Ejercicio1 {
    public static void main(String[] args){
        String nombres = "Alessander Jesus";
        String primerApellido = "Carazas";
        String segundoApellido = "Quispe";
        double estatura = 1.78;
        double peso = 85.7;
        
        System.out.println("Su nombre es: "+ nombres + " " + primerApellido + " " + segundoApellido);
        System.out.println("Su estatura es: "+ estatura + " metros.");
        System.out.println("Y su peso: "+ peso + " kilogramos.");
    }
}
