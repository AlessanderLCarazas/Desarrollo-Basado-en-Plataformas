<?
	$bg_color = $_GET["color"];
	setcookie("colorFondo",$bg_color, time()+60*60*24*365);
?>

