package modelo;

public class PruebaBD {

    public static void main(String[] args) {
        BDConexion conn = new BDConexion();
    }
    
}
