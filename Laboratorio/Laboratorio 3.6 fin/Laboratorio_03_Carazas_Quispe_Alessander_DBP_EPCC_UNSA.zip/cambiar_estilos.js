function cambiar_estilos() {
	document.getElementById("cuadro").className="cam_cuadro_1";
	document.getElementById("texto").className="cam_texto_1";
	document.getElementById("cuadro2").className="cam_cuadro_2";
	document.getElementById("texto2").className="cam_texto_2";
}