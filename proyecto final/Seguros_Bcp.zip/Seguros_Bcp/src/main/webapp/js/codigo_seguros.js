
function cambia_de_pagina()
    {
        document.getElementById("modal").style.visibility = "visible" ;
    }
function cambia_de_pagina2()
    {
        document.getElementById("modal2").style.visibility = "visible" ;
    }   
function cambia_de_pagina3()
    {
        document.getElementById("modal3").style.visibility = "visible" ;
    }
function cambia_de_pagina4()
    {
        location.href="https://web.pacifico.com.pe/seguros/soat/compraonline/bcp?from=viabcp_null_02_2022_aon_soat_soat_conversiones_banners_todos_soat-viabcp-feb22_null&utm_source=viabcp&utm_medium=null&utm_campaign=PBS_soat_AONPlataformas_aon_soat_2022_02_ECOM_null_aon-regular_conversiones_null_soat-viabcp-feb22_bbdd_todos_null_todos_NOPAID_todos_null_null&utm_content=null_soat-viabcp-feb22_null_nullseg_null_null_banners_null&_ga=2.105393731.1720268357.1660949607-561105847.1658354231#/inicio";
    }
       
function cierra_pagina(){
    document.getElementById("modal").style.visibility = "hidden" ;
}   
function cierra_pagina2(){
    document.getElementById("modal2").style.visibility = "hidden" ;
} 
function cierra_pagina3(){
    document.getElementById("modal3").style.visibility = "hidden" ;
} 