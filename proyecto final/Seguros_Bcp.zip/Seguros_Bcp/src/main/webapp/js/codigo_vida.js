function cambia_de_pagina()
    {
        location.href="https://loginunico.viabcp.com/#/verificar-sesion";
    }
function cambia_de_pagina2()
    {
        location.href="https://www.viabcp.com/wcm/connect/97f9192b-f0c7-4f01-9dea-e62c296cdc9a/Onco+Respaldo+Digital++%282%29.pdf?MOD=AJPERES&attachment=false&id=1651002924916";
    }
function cambia_de_pagina3()
    {
        document.getElementById("modal2").style.visibility = "visible" ;
    } 
function cierra_pagina2(){
    document.getElementById("modal2").style.visibility = "hidden" ;
}     