function cambia_de_pagina2()
    {
        location.href="https://loginunico.viabcp.com/#/bcp-login/SJ/3338b60f-debb-42eb-93e9-70d9212c3c2a/RLTAM";
    }